<?php
include('include/head.php');
?>
<?php
include('include/header.php');
?>
  <div class="home-slider home-slider-two owl-theme owl-carousel">
    <div class="slider-item slider-item-img-two">
      <div class="d-table">
        <div class="d-table-cell">
          <div class="container">
            <div class="slider-text">
              <div class="slider-shape">
                <img src="assets/img/home-one/5.png" alt="Shape">
              </div>
              <h1>
              Innovative Diabetes Care and Support for Every Step of the Journey
              </h1>
              <p>
                Everyday we bring hope and smile to the patient we serve
              </p>
              <div class="common-btn">
                <a href="appointment.html">
                  Get Appointment
                </a>
                <a class="cmn-btn-right" href="about.html">
                  Learn More
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="slider-item slider-item-img-three">
      <div class="d-table">
        <div class="d-table-cell">
          <div class="container">
            <div class="slider-text">
              <div class="slider-shape">
                <img src="assets/img/home-one/5.png" alt="Shape">
              </div>
              <h1>
              Expert Diabetes Care for a Healthier Life
              </h1>
              <p>
              Everyday we bring hope and smile to the patient we serve
              </p>
              <div class="common-btn">
                <a href="appointment.html">
                  Get Appointment
                </a>
                <a class="cmn-btn-right" href="about.html">
                  Learn More
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="slider-item slider-item-img-four">
      <div class="d-table">
        <div class="d-table-cell">
          <div class="container">
            <div class="slider-text">
              <div class="slider-shape">
                <img src="assets/img/home-one/5.png" alt="Shape">
              </div>
              <h1>
              Specialized Diabetes Care Tailored to Your Needs
              </h1>
              <p>
              Effective Strategies for Managing Diabetes and Improving Health
              </p>
              <div class="common-btn">
                <a href="appointment.html">
                  Get Appointment
                </a>
                <a class="cmn-btn-right" href="about.html">
                  Learn More
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="emergency-area">
    <div class="container">
      <div class="row emergency-bg">
        <div class="col-sm-6 col-lg-4">
          <div class="emergency-item">
            <i class="icofont-ui-call">
            </i>
            <div class="emergency-inner">
              <h3>
                Emergency Call
              </h3>
              <a href="tel:+0755543332322">
              +91- 9560149479
              </a>
              <a href="tel:+0754647665322">
              +011-42254000
              </a>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4">
          <div class="emergency-item">
            <i class="icofont-location-pin">
            </i>
            <div class="emergency-inner">
              <h3>
                Location
              </h3>
              <p>
              A-168/1, First Floor, Near Top-man showroom, Ganesh Nagar, New Delhi - 110018, India

              </p>
            </div>
          </div>
        </div>
        <div class="col-sm-6   col-lg-4">
          <div class="emergency-item">
          <i class="icofont-clock-time"></i>
            <div class="emergency-inner">
              <h3>
                OPD Timing
              </h3>
<p>Mon - Sat :  6 pm - 8 pm <br>Mon - Sat : 12 noon - 2 pm
</p>

             
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="about-area about-area-two pt-100 pb-70">
<div class="container">
<div class="row align-items-center justify-content-center">
<div class="col-lg-5">
<div class="about-item">
<div class="about-left">
<img src="assets/img/Rishikesh-Dessai.png" alt="About">
</div>
</div>
</div>
<div class="col-lg-7">
<div class="about-item about-right">
<img src="assets/img/home-one/5.png" alt="About">
<h2>Current post and outline of Experience </h2>
<p>I am presently working as Associate Consultant & Associate Professor (GRIPMER) in Department of Internal Medicine, Sir Ganga Ram Hospital & associated Hospitals, New Delhi.  The post includes taking independent rounds in ward, taking clinical decisions and supervising all ward activities including procedures. Besides this, the other duties include teaching postgraduate students, nursing staff and supervising the teaching schedules. There is a daily ward round in which I conduct bedside clinics for postgraduates and registrars. I have special interest in diabetes management .I also conduct free OPDs for medical patients medicine,HIV and Rheumatology twice a week.  Besides this I hold private OPD for 2 hours per day.</p>
<p> The department conducts Medicine update once a year, a popular event which caters to general practitioners and family physicians. I was active part of Medicine update in years 2016, 2017, 2018, 2019 and 2020. </p>
<a href="about.html">Know More</a>
</div>
</div>
</div>
</div>
</div>





 
  <section class="services-area pb-70">
    <div class="container">
      <div class="section-title-two">
        <span>
          Services
        </span>
        <h2>
          Our Hospital Services
        </h2>
      </div>
      <div class="row justify-content-center">
        <div class="col-sm-6 col-lg-4 wow fadeInUp" data-wow-delay=".3s">
          <div class="service-item">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="service-front">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                  Diabetes Management
                  </h3>
                  <p>
                  When the blood sugar levels are too high or blood glucose is not metabolized properly it gives rise to the chronic condition called diabetes
                  </p>
                </div>
                <div class="service-end">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                  Diabetes Management
                  </h3>
                  <p>
                  When the blood sugar levels are too high or blood glucose is not metabolized properly it gives rise to the chronic condition called diabetes
                  </p>
                  <a href="service-details.html">
                    Read More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 wow fadeInUp" data-wow-delay=".5s">
          <div class="service-item">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="service-front">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Thyroid Management
                  </h3>
                  <p>
                    Your thyroid creates and produces hormones that play a role in many different systems throughout your body. When your thyroid makes either too..

                  </p>
                </div>
                <div class="service-end">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Thyroid Management
                  </h3>
                  <p>
                    Your thyroid creates and produces hormones that play a role in many different systems throughout your body. When your thyroid makes either too..

                  </p>
                  <a href="service-details.html">
                    Read More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 wow fadeInUp" data-wow-delay=".7s">
          <div class="service-item">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="service-front">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Cardiac Problems
                  </h3>
                  <p>
                    It’s always best to discuss your heart condition with your health professional or heart specialist who can advise you on the correct diagnosis..
                  </p>
                </div>
                <div class="service-end">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Cardiac Problems
                  </h3>
                  <p>
                    It’s always best to discuss your heart condition with your health professional or heart specialist who can advise you on the correct diagnosis..
                  </p>
                  <a href="service-details.html">
                    Read More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 wow fadeInUp" data-wow-delay=".9s">
          <div class="service-item">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="service-front">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Bronchial Asthma
                  </h3>
                  <p>
                    In bronchial asthma airway path to the lungs become narrow due to swelling. The swelling causes an increase in mucus production.
                  </p>
                </div>
                <div class="service-end">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Bronchial Asthma
                  </h3>
                  <p>
                    In bronchial asthma airway path to the lungs become narrow due to swelling. The swelling causes an increase in mucus production.
                  </p>
                  <a href="service-details.html">
                    Read More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 wow fadeInUp" data-wow-delay=".3s">
          <div class="service-item">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="service-front">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Digestive Problems
                  </h3>
                  <p>
                    Digestive problems such as GERD, gallstones, celiac disease, hemorrhoids, colitis, etc. need specialized care and treatment.
                  </p>
                </div>
                <div class="service-end">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Digestive Problems
                  </h3>
                  <p>
                    Digestive problems such as GERD, gallstones, celiac disease, hemorrhoids, colitis, etc. need specialized care and treatment.
                  </p>
                  <a href="service-details.html">
                    Read More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 wow fadeInUp" data-wow-delay=".5s">
          <div class="service-item">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="service-front">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Kidney Problems
                  </h3>
                  <p>
                  The key role of the kidney is to remove toxins, waste, and excess water from the bloodstream to be carried out of the system through the urine.
                  </p>
                </div>
                <div class="service-end">
                  <i class="icofont-doctor">
                  </i>
                  <h3>
                    Kidney Problems
                  </h3>
                  <p>
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                  </p>
                  <a href="service-details.html">
                    Read More
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
        
       
      </div>
    </div>
  </section>

  <section class="welcome-area ptb-100">
    <div class="container-fluid p-0">
      <div class="row m-0">
        <div class="col-lg-6 p-0">
          <div class="welcome-item welcome-left">
            <img src="assets/img/home-two/3.jpg" alt="image">
          </div>
        </div>
        <div class="col-lg-6 p-0">
          <div class="welcome-item welcome-right">
            <div class="section-title-two">
              <span>
              Professional Experience
              </span>
              <h2>
                Why Choose Us
              </h2>
            </div>
            <ul>
              <li class="wow fadeInUp" data-wow-delay=".3s">
                <i class="icofont-doctor-alt">
                </i>
                <div class="welcome-inner">
                  <h3>
                  Expertise and Experience:
                  </h3>
                  <p>
                  We have a track record of successfully managing diabetes for numerous patients, helping them achieve better health outcomes and improve their quality of life.
                  </p>
                </div>
              </li>
              <li class="wow fadeInUp" data-wow-delay=".5s">
              <i class="icofont-doctor-alt">
                </i>
                <div class="welcome-inner">
                  <h3>
                  Personalized and Comprehensive Care:
                  </h3>
                  <p>
                  We offer customized treatment plans that address your specific type of diabetes, medical history, and lifestyle, ensuring a holistic approach to your health.  
                  </p>
                </div>
              </li>
              <li class="wow fadeInUp" data-wow-delay=".7s">
              <i class="icofont-doctor-alt">
              </i>
                <div class="welcome-inner">
                  <h3>
                  Advanced Technology and Innovative Solutions:
                  </h3>
                  <p>
                  We use state-of-the-art diagnostic tools and monitoring technologies to accurately track and manage your condition, providing precise and effective treatment.
                  </p>
                </div>
              </li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </section>



  <div class="video-wrap video-wrap-two">
    <div class="container-fluid p-0">
      <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="pills-home" role="tabpanel"
        aria-labelledby="pills-home-tab">
          <div class="video-area">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="container">
                  <div class="video-item">
                    <!-- <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="popup-youtube">
                      <i class="icofont-ui-play">
                      </i>
                    </a> -->
                    <div class="video-content">
                      <h3>
                      Professional Qualifications
                      </h3>
                     <ul class="text-white">
                    <li>MBBS: 2007 -  Bharati Vidyapeeth Medical College, Pune, Maharashtra </li>
                    <li>MD Internal Medicine: 2013 -  Bharati Vidyapeeth Medical College, Pune, Maharashtra </li>

                     </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
          <div class="video-area">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="container">
                  <div class="video-item">
                    <!-- <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="popup-youtube">
                      <i class="icofont-ui-play">
                      </i>
                    </a> -->
                    <div class="video-content">
                      <h3>
                      Professional Skills
                      </h3>
                     <ul class="text-white">
                        <li>Patient Interaction </li>
                        <li>Training undergraduates and post graduate students in General Medicine.</li>
                        <li>Managing medical emergencies and complications .</li>
                     </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
          <div class="video-area">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="container">
                  <div class="video-item">
                    <!-- <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="popup-youtube">
                      <i class="icofont-ui-play">
                      </i>
                    </a> -->
                    <div class="video-content">
                      <h3>
                      Experience
                      </h3>
                     <ul class="text-white">
                        <li>August 2018 – till date : Working as an Associate Consultant/ Associate Professor in Department of Medicine at Sir Ganga Ram Hospital, New Delhi.  </li>
                        <li>November 2015 – July 2018 : Worked as a Senior Resident in Department of Medicine at Sir Ganga Ram Hospital, New Delhi.  </li>
                        <li>
                        April 2014– October 2015 : Worked as a Senior Resident in Department of Medicine at Sir Ganga Ram City Hospital, New Delhi.
                        </li>
                     </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="pills-icu" role="tabpanel" aria-labelledby="pills-icu-tab">
          <div class="video-area">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="container">
                  <div class="video-item">
                    <!-- <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="popup-youtube">
                      <i class="icofont-ui-play">
                      </i>
                    </a> -->
                    <div class="video-content">
                      <h3>
                      Registrations
                      </h3>
                      <ul class="text-white">
                        <li>1.	DMC Reg. No.: 67398</li>
                        <li>2.	Maharashtra Medical Council Reg. No.:2008093190</li>
                        <li>3.	IMA-DNZ: 3959</li>
                        <li>4.	API Life Membership: L-16544</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="tab-pane fade" id="pills-doctor" role="tabpanel" aria-labelledby="pills-doctor-tab">
          <div class="video-area">
            <div class="d-table">
              <div class="d-table-cell">
                <div class="container">
                  <div class="video-item">
                    <!-- <a href="http://www.youtube.com/watch?v=0O2aH4XLbto" class="popup-youtube">
                      <i class="icofont-ui-play">
                      </i>
                    </a> -->
                    <div class="video-content">
                      <h3>
                      Presentations
                      </h3>
                     <ul class="text-white">
                        <li>1.	Reversible Cutaneous Hyperpigmentation in Vitamin B12 deficiency- secured second place at KARGERICON 2011. </li>
                        <li>2.	Rare Presentation of Infections in Elderly Diabetics- MAPCON 2012.</li>
                        <li>3.	Does Fat distribution in body correlates with radiological features of osteoarthritis?- . Kakar, D Shah. A Gogia, VR Manohar, Rishikesh Dessai, M Dhawan, KK Saxena. At IRACON 2017.</li>
                        <li>4.	IRIS masquerading as Molluscum Contagiosum in immunocompetent patient with disseminated histoplasmosis- IRACON 2017.</li>
                        <li>5.	Frequency and pattern of neurological involvement in Chikungunya patients-  S. Reddy, Kunal C., Rishikesh Dessai, S.Jain. APICON 2018.</li>
                        <li>6.	Outcome of Mucormycosis in COVID-19: An Observational Study- R. Dessai, P. Khosla, V. Taneja, A. Kakar, K. Chawla, A. Gersovale. APICON 2022.</li>
                     </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container">
      <ul class="video-nav nav nav-pills" id="pills-tab" role="tablist">
        <li class="nav-item video-nav-item">
          <a class="nav-link active" id="pills-home-tab" data-bs-toggle="pill" href="#pills-home"
          role="tab" aria-controls="pills-home" aria-selected="true">
         Qualifications
          </a>
        </li>
        <li class="nav-item video-nav-item">
          <a class="nav-link" id="pills-profile-tab" data-bs-toggle="pill" href="#pills-profile"
          role="tab" aria-controls="pills-profile" aria-selected="false">
          Professional Skills
          </a>
        </li>
        <li class="nav-item video-nav-item">
          <a class="nav-link" id="pills-contact-tab" data-bs-toggle="pill" href="#pills-contact"
          role="tab" aria-controls="pills-contact" aria-selected="false">
          Experience
          </a>
        </li>
        <li class="nav-item video-nav-item">
          <a class="nav-link" id="pills-icu-tab" data-bs-toggle="pill" href="#pills-icu"
          role="tab" aria-controls="pills-icu" aria-selected="false">
          Registrations
          </a>
        </li>
        <li class="nav-item video-nav-item">
          <a class="nav-link" id="pills-doctor-tab" data-bs-toggle="pill" href="#pills-doctor"
          role="tab" aria-controls="pills-doctor" aria-selected="false">
          Presentations
          </a>
        </li>
      </ul>
    </div>
  </div>

  <div class="counter-area counter-area-two">
    <div class="container">
      <div class="row counter-bg">
        <div class="col-sm-6 col-md-3 col-lg-3">
          <div class="counter-item">
          <i class="icofont-book"></i>
            <h3>
              <span class="odometer" data-count="850">
                00
              </span>
            </h3>
            <p>
              Research and Publication
            </p>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3">
          <div class="counter-item">
            <i class="icofont-people">
            </i>
            <h3>
              <span class="odometer" data-count="2500">
                00
              </span>
              <span class="target">
                +
              </span>
            </h3>
            <p>
              Happy Patients
            </p>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3">
          <div class="counter-item">
            <i class="icofont-doctor-alt">
            </i>
            <h3>
              <span class="odometer" data-count="750">
                00
              </span>
            </h3>
            <p>
              Surgeries
            </p>
          </div>
        </div>
        <div class="col-sm-6 col-md-3 col-lg-3">
          <div class="counter-item">
            <i class="icofont-badge">
            </i>
            <h3>
              <span class="odometer" data-count="18">
                00
              </span>
            </h3>
            <p>
              Year Experience
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
  <section class="appointment-area pb-100">
    <div class="container-fluid p-0">
      <div class="appointment-item">
        <h2>
          Book your appointment
        </h2>
        <span>
          We will confirm your appointment within 2 hours
        </span>
        <div class="appointment-form">
          <form>
            <div class="row justify-content-center">
              <div class="col-lg-6">
                <div class="form-group">
                  <i class="icofont-business-man-alt-1">
                  </i>
                  <label>
                    Name
                  </label>
                  <input type="text" class="form-control" placeholder="Enter Your Name">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <i class="icofont-ui-message">
                  </i>
                  <label>
                    Email
                  </label>
                  <input type="email" class="form-control" placeholder="Enter Your Email">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <i class="icofont-ui-call">
                  </i>
                  <label>
                    Phone
                  </label>
                  <input type="text" class="form-control" placeholder="Enter Your Number">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <i class="icofont-hospital">
                  </i>
                  <label>
                    Services
                  </label>
                  <select class="form-control" id="exampleFormControlSelect1">
                    <option>
                    Diabetes Management
                    </option>
                    <option>
                    Thyroid Management
                    </option>
                    <option>
                    Cardiac Problems

                    </option>
                    <option>
                    Bronchial Asthma

                    </option>
                  </select>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                <i class="icofont-calendar"></i>
                  
                  <label for="appointmentDate">Choose Appointment Date:</label>
<input type="date" id="appointmentDate" class="form-control">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="form-group">
                  <i class="icofont-business-man">
                  </i>
                  <label>
                    Age
                  </label>
                  <input type="text" class="form-control" placeholder="Your Age">
                </div>
              </div>
            </div>
            <div class="text-center">
              <button type="submit" class="btn appointment-btn">
                Submit
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  


  <section class="blog-area pt-100 pb-70">
    <div class="container">
      <div class="section-title-two">
        <span>
          Blogs
        </span>
        <h2>
          Our latest blogs
        </h2>
      </div>
      <div class="row justify-content-center">
        <div class="col-sm-6 col-lg-4 wow fadeInUp" data-wow-delay=".3s">
          <div class="blog-item">
            <div class="blog-top">
              <a href="blog-details.html">
                <img src="assets/img/31.webp" alt="Blog">
              </a>
            </div>
            <div class="blog-bottom">
              <h3>
                <a href="blog-details.html">
                Latest Advancement in Internal Medicine
                </a>
              </h3>
              <p>
              Welcome to a groundbreaking exploration of the latest advancements in internal medicine.

              </p>
              <ul>
                <li>
                  <a href="blog-details.html">
                    Read More
                    <i class="icofont-long-arrow-right">
                    </i>
                  </a>
                </li>
                <li>
                  <i class="icofont-calendar">
                  </i>
                  Jan 03, 2024
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-4 wow fadeInUp" data-wow-delay=".5s">
          <div class="blog-item">
            <div class="blog-top">
              <a href="blog-details.html">
                <img src="assets/img/32.webp" alt="Blog">
              </a>
            </div>
            <div class="blog-bottom">
              <h3>
                <a href="blog-details.html">
                Impact of Lifestyle Factors on Chronic Disease
                </a>
              </h3>
              <p>
              A healthy lifestyle is the cornerstone of preventing chronic diseases and promoting overall well-being.

              </p>
              <ul>
                <li>
                  <a href="blog-details.html">
                    Read More
                    <i class="icofont-long-arrow-right">
                    </i>
                  </a>
                </li>
                <li>
                  <i class="icofont-calendar">
                  </i>
                  Jan 03, 2024
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-6   col-lg-4 wow fadeInUp" data-wow-delay=".7s">
          <div class="blog-item">
            <div class="blog-top">
              <a href="blog-details.html">
                <img src="assets/img/33.webp" alt="Blog">
              </a>
            </div>
            <div class="blog-bottom">
              <h3>
                <a href="blog-details.html">
                Role of Preventive Care in Internal Medicine
                </a>
              </h3>
              <p>
              Are you aware of the crucial role preventive care plays in internal medicine?

              </p>
              <ul>
                <li>
                  <a href="blog-details.html">
                    Read More
                    <i class="icofont-long-arrow-right">
                    </i>
                  </a>
                </li>
                <li>
                  <i class="icofont-calendar">
                  </i>
                  Jan 03, 2024
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


  <!-- <section class="review-area pb-100">
<div class="container">
<div class="main">
<div class="slider-nav">
<div>
<div class="review-img">
<img src="assets/img/home-three/7.png" alt="Feedback">
</div>
<div class="review-details">
<h3>Adision Smith</h3>
<span>Designer</span>
</div>
</div>
<div>
<div class="review-img">
<img src="assets/img/home-three/8.png" alt="Feedback">
</div>
<div class="review-details">
<h3>John Cena</h3>
<span>Designer</span>
</div>
</div>
<div>
<div class="review-img">
<img src="assets/img/home-three/9.png" alt="Feedback">
</div>
<div class="review-details">
<h3>Mac Smith</h3>
<span>Designer</span>
</div>
</div>
<div>
<div class="review-img">
<img src="assets/img/home-three/9.png" alt="Feedback">
</div>
<div class="review-details">
<h3>Shane Watson</h3>
<span>Designer</span>
</div>
</div>
</div>
<div class="slider-for">
<div>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra</p>
</div>
<div>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra</p>
</div>
<div>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra</p>
</div>
<div>
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo viverra</p>
</div>
</div>
</div>
</div>
</section> -->
  <?php
include('include/footer.php');
?>