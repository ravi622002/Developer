<body>
  <div class="loader">
    <div class="d-table">
      <div class="d-table-cell">
        <div class="spinner">
          <div class="double-bounce1">
          </div>
          <div class="double-bounce2">
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="header-top">
    <div class="container">
      <div class="row align-items-center justify-content-center">
        <div class="col-sm-9 col-lg-9">
          <div class="header-top-item">
            <div class="header-top-left">
              <ul>
                <li>
                  <a href="tel:+07554332322">
                    <i class="icofont-ui-call">
                    </i>
                    Call : +91- 9560149479
                  </a>
                </li>
                <li>
                  <a href="https://templates.hibootstrap.com/cdn-cgi/l/email-protection#4129242d2d2e012c24253224376f222e2c">
                    <i class="icofont-ui-message">
                    </i>
                    <span class="__cf_email__" data-cfemail="c1a9a4adadae81aca4a5b2a4b7efa2aeac">
                    desairishikesh@rediffmail.com
                    </span>
                  </a>
                </li>
                <li>
                  <i class="icofont-location-pin">
                  </i>
                  Ganesh Nagar, New Delhi - 110018, India

                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-3 col-lg-3">
          <div class="header-top-item">
            <div class="header-top-right">
              <ul>
                <li>
                  <a href="https://www.facebook.com/login/" target="_blank">
                    <i class="icofont-facebook">
                    </i>
                  </a>
                </li>
                <li>
                  <a href="https://twitter.com/login/" target="_blank">
                    <i class="icofont-twitter">
                    </i>
                  </a>
                </li>
                <li>
                  <a href="https://www.pinterest.com/" target="_blank">
                    <i class="icofont-pinterest">
                    </i>
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="navbar-area sticky-top">
    <div class="mobile-nav">
      <a href="index.html" class="logo">
        <img src="assets/img/logo-two.png" alt="Logo">
      </a>
    </div>
    <div class="main-nav">
      <div class="container">
        <nav class="navbar navbar-expand-md navbar-light">
          <a class="navbar-brand" href="index.html">
            <h3>Rishikesh</h3>
            <!-- <img src="assets/img/logo.png" alt="Logo"> -->
          </a>
          <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
            <ul class="navbar-nav">
              <li class="nav-item">
                <a href="#" class="nav-link dropdown-toggle active">
                  Home
                </a>
                
              </li>
              <li class="nav-item">
                <a href="about.html" class="nav-link">
                  About
                </a>
              </li>
              
              <li class="nav-item">
                <a href="#" class="nav-link dropdown-toggle">
                  Services
                </a>
                <ul class="dropdown-menu">
                  <li class="nav-item">
                    <a href="service.html" class="nav-link">
                    Diabetes Management
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="service-details.html" class="nav-link">
                    Thyroid Management
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="service-details.html" class="nav-link">
                    Cardiac Problems
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="service-details.html" class="nav-link">
                    Bronchial Asthma
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="service-details.html" class="nav-link">
                    Digestive Problems
                    </a>
                  </li>
                  <li class="nav-item">
                    <a href="service-details.html" class="nav-link">
                    Kidney Problems
                    </a>
                  </li>

                </ul>
              </li>
              
              <li class="nav-item">
                <a href="#" class="nav-link ">
                  Blog
                </a>
                
              </li>
              <li class="nav-item">
                <a href="contact.html" class="nav-link">
                  Contact Us
                </a>
              </li>
            </ul>
            <div class="nav-srh">
              <div class="search-toggle">
                <button class="search-icon icon-search">
                  <i class="icofont-search-1">
                  </i>
                </button>
                <button class="search-icon icon-close">
                  <i class="icofont-close">
                  </i>
                </button>
              </div>
              <div class="search-area">
                <form>
                  <input type="text" class="src-input" id="search-terms" placeholder="Search here..."
                  />
                  <button type="submit" name="submit" value="Go" class="search-icon">
                    <i class="icofont-search-1">
                    </i>
                  </button>
                </form>
              </div>
            </div>
          </div>
        </nav>
      </div>
    </div>
  </div>