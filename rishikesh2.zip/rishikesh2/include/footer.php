<footer class="pb-70">
    
    <div class="container">
      <div class="row justify-content-center">
        <div class="col-sm-6 col-lg-4">
          <div class="footer-item">
            <div class="footer-contact">
              <h3>
                Contact Us
              </h3>
              <ul>
                <li>
                  <i class="icofont-ui-message">
                  </i>
                  <a href="https://templates.hibootstrap.com/cdn-cgi/l/email-protection#b8d1d6ded7f8d5dddcd1cbddce96dbd7d5">
                    <span class="__cf_email__" data-cfemail="7c15121a133c111918150f190a521f1311">
                      desairishikesh@rediffmail.com
                    </span>
                  </a>
                  <a href="https://templates.hibootstrap.com/cdn-cgi/l/email-protection#18707d74747758757d7c716b7d6e367b7775">
                    <span class="__cf_email__" data-cfemail="177f727b7b78577a72737e6472613974787a">
                      desairishikesh@rediffmail.com
                    </span>
                  </a>
                </li>
                <li>
                  <i class="icofont-stock-mobile">
                  </i>
                  <a href="tel:+07554332322">
                    Call: +91- 9560149479
                  </a>
                  <a href="tel:+236256256365">
                    Call: +011-42254000
                  </a>
                </li>
                <li>
                  <i class="icofont-location-pin">
                  </i>
                  A-168/1, First Floor, Near Top-man showroom, Ganesh Nagar, New Delhi - 110018, India

                
                 
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-2">
          <div class="footer-item">
            <div class="footer-quick">
              <h3>
                Quick Links
              </h3>
              <ul>
                <li>
                  <a href="about.html">
                    About us
                  </a>
                </li>
                <li>
                  <a href="blog.html">
                    Blog
                  </a>
                </li>
                <li>
                  <a href="blog-details.html">
                    Our Expertise
                  </a>
                </li>
                <li>
                  <a href="faq.html">
                    Faq
                  </a>
                </li>
                <li>
                  <a href="doctor.html">
                    Services
                  </a>
                </li>
                <li>
                  <a href="contact.html">
                    Contact us
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="footer-item">
            <div class="footer-quick">
              <h3>
                Our Services
              </h3>
              <ul>
                <li>
                  <a href="service-details.html">
                  Diabetes Management
                  </a>
                </li>
                <li>
                  <a href="service-details.html">
                  Thyroid Management
                  </a>
                </li>
                <li>
                  <a href="service-details.html">
                  Thyroid Management
                  </a>
                </li>
                <li>
                  <a href="service-details.html">
                  Bronchial Asthma
                  </a>
                </li>
                <li>
                  <a href="service-details.html">
                  Digestive Problems
                  </a>
                </li>
                <li>
                  <a href="service-details.html">
                  Kidney Problems
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
        <div class="col-sm-6 col-lg-3">
          <div class="footer-item">
            <div class="footer-feedback">
              <h3>
                Feedback
              </h3>
              <form>
                <div class="form-group">
                  <input type="text" class="form-control" placeholder="Name">
                </div>
                <div class="form-group">
                  <input type="text" class="form-control" placeholder="Phone">
                </div>
                <div class="form-group">
                  <textarea class="form-control" id="your_message" rows="5" placeholder="Message">
                  </textarea>
                </div>
                <div class="text-left">
                  <button type="submit" class="btn feedback-btn">
                    SUBMIT
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer>
  <div class="copyright-area">
    <div class="container">
      <div class="copyright-item">
        <p>
          ©
          <span>
            Rishkiesh
          </span>
          Developed by
          <a href="https://hibootstrap.com/" target="_blank">
           The Story door
          </a>
        </p>
      </div>
    </div>
  </div>
  <script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js">
  </script>
  <script src="assets/js/jquery.min.js">
  </script>
  <script src="assets/js/bootstrap.bundle.min.js">
  </script>
  <script src="assets/js/owl.carousel.min.js">
  </script>
  <script src="assets/js/jquery.meanmenu.js">
  </script>
  <script src="assets/js/slick.min.js">
  </script>
  <script src="assets/js/jquery.magnific-popup.min.js">
  </script>
  <script src="assets/js/wow.min.js">
  </script>
  <script src="assets/js/jquery.ajaxchimp.min.js">
  </script>
  <script src="assets/js/form-validator.min.js">
  </script>
  <script src="assets/js/contact-form-script.js">
  </script>
  <script src="assets/js/odometer.min.js">
  </script>
  <script src="assets/js/jquery.appear.min.js">
  </script>
  <script src="assets/js/custom.js">
  </script>
</body>


</html>